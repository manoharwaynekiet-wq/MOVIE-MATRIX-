MOVIE MATRIX — NETLIFY WEBSITE

This is a complete static mini-project website.

Files:
- index.html
- style.css
- script.js

Features:
- Cinematic minimalist "Movie Matrix" design
- Smooth entrance and floating poster animations
- Movie recommendation cards
- Visual rating matrix
- SVD mathematics explanation
- Interactive preference sliders
- Netlify Forms review collection

To test:
1. Extract the ZIP.
2. Double-click index.html.

To publish:
1. Open Netlify and sign in.
2. Create a new site and deploy the folder manually.
3. After deployment, Netlify Forms will collect reviews from the "movie-review" form.
