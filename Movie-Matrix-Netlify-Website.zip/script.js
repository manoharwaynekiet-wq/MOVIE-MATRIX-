const movieData=[
 {title:"Interstellar",genre:"SCI-FI · DRAMA",rating:"4.86",reason:"Strong match for your sci-fi preference"},
 {title:"Inception",genre:"SCI-FI · THRILLER",rating:"4.78",reason:"Hidden-factor similarity is high"},
 {title:"The Dark Knight",genre:"ACTION · THRILLER",rating:"4.74",reason:"Matches your thriller pattern"},
 {title:"Arrival",genre:"SCI-FI · DRAMA",rating:"4.69",reason:"Similar user taste profile"}
];
const movies=document.querySelector("#movies");
function render(list){movies.innerHTML=list.map(m=>`<article class="movie"><div class="movie-art"><span class="genre">${m.genre}</span><h3>${m.title}</h3></div><div class="movie-info"><h4>${m.title}</h4><div class="rating">★ ${m.rating} / 5</div><p>${m.reason}</p></div></article>`).join("")}
render(movieData);
document.querySelector("#refresh").onclick=()=>{render([...movieData].sort(()=>Math.random()-.5));};

const sliders=[["sci","sciOut"],["thr","thrOut"],["dra","draOut"]];
function updateScore(){
 let s=+sci.value,t=+thr.value,d=+dra.value;
 document.querySelector("#sciOut").textContent=s+"%";
 document.querySelector("#thrOut").textContent=t+"%";
 document.querySelector("#draOut").textContent=d+"%";
 let score=(s*.021+t*.014+d*.009+2.1).toFixed(2);
 document.querySelector("#score").textContent=Math.min(5,score);
}
sliders.forEach(([id])=>document.querySelector("#"+id).addEventListener("input",updateScore));
updateScore();
